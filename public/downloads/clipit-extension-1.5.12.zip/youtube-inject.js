/**
 * Injected into YouTube page context to intercept timedtext (subtitle) requests.
 * This captures YouTube's actual working subtitle fetches.
 */
(function() {
  console.log('[ClipIt Interceptor] YouTube timedtext interceptor starting...');

  // Store captured subtitles by URL to avoid duplicates
  const capturedUrls = new Set();

  function captureTimedtext(lang, videoId, url, content) {
    const uniqueKey = `${videoId}_${lang}`;
    if (capturedUrls.has(uniqueKey)) {
      console.log('[ClipIt Interceptor] Already captured:', uniqueKey);
      return;
    }
    if (!content || content.length <= 10) {
      console.log('[ClipIt Interceptor] Empty or very short response for', lang);
      return;
    }

    capturedUrls.add(uniqueKey);
    console.log('[ClipIt Interceptor] Captured timedtext:', lang, 'length:', content.length);
    window.postMessage({
      type: 'CLIPIT_TIMEDTEXT_CAPTURED',
      lang,
      content,
      url,
    }, '*');
  }

  function getPlayerResponse() {
    if (window.ytInitialPlayerResponse) return window.ytInitialPlayerResponse;

    const rawResponse = window.ytplayer?.config?.args?.player_response;
    if (typeof rawResponse === 'string') {
      try {
        return JSON.parse(rawResponse);
      } catch (error) {
        console.warn('[ClipIt Interceptor] Could not parse player response:', error);
      }
    }
    return rawResponse || null;
  }

  async function fetchSignedTrack(track, videoId, originalFetch) {
    if (!track?.baseUrl || !track?.languageCode) return false;
    try {
      const url = new URL(track.baseUrl);
      url.searchParams.set('fmt', 'json3');
      const response = await originalFetch(url.toString(), { credentials: 'include' });
      const content = await response.text();
      captureTimedtext(track.languageCode, videoId, url.toString(), content);
      return content.length > 10;
    } catch (error) {
      console.warn('[ClipIt Interceptor] Signed caption fetch failed for', track.languageCode, error);
      return false;
    }
  }

  // Intercept fetch
  const originalFetch = window.fetch;
  window.fetch = async function(...args) {
    const url = args[0]?.url || args[0];

    // Log all fetch requests for debugging
    if (url && typeof url === 'string' && (url.includes('timedtext') || url.includes('caption'))) {
      console.log('[ClipIt Interceptor] Fetch request detected:', url.substring(0, 100));
    }

    const response = await originalFetch.apply(this, args);

    if (url && typeof url === 'string' && url.includes('/api/timedtext')) {
      // Create a unique key for this request (lang + video)
      const langMatch = url.match(/[&?]lang=([^&]+)/);
      const lang = langMatch ? langMatch[1] : 'unknown';
      const videoMatch = url.match(/[&?]v=([^&]+)/);
      const videoId = videoMatch ? videoMatch[1] : 'unknown';
      const uniqueKey = `${videoId}_${lang}`;

      // Skip if we already captured this exact request
      if (capturedUrls.has(uniqueKey)) {
        console.log('[ClipIt Interceptor] Already captured:', uniqueKey);
        return response;
      }

      try {
        const clone = response.clone();
        const text = await clone.text();
        console.log('[ClipIt Interceptor] Timedtext response for', lang, '- length:', text.length);

        if (text && text.length > 10) {
          capturedUrls.add(uniqueKey);
          console.log('[ClipIt Interceptor] Captured timedtext via fetch:', lang, 'length:', text.length);
          window.postMessage({
            type: 'CLIPIT_TIMEDTEXT_CAPTURED',
            lang: lang,
            content: text,
            url: url
          }, '*');
        } else {
          console.log('[ClipIt Interceptor] Empty or very short response for', lang);
        }
      } catch (e) {
        console.log('[ClipIt Interceptor] Error processing fetch:', e.message);
      }
    }
    return response;
  };

  // Intercept XMLHttpRequest
  const originalXHROpen = XMLHttpRequest.prototype.open;
  const originalXHRSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function(method, url, ...rest) {
    this._clipitUrl = url;
    // Log XHR requests for debugging
    if (url && typeof url === 'string' && (url.includes('timedtext') || url.includes('caption'))) {
      console.log('[ClipIt Interceptor] XHR request detected:', url.substring(0, 100));
    }
    return originalXHROpen.apply(this, [method, url, ...rest]);
  };

  XMLHttpRequest.prototype.send = function(...args) {
    this.addEventListener('load', function() {
      if (this._clipitUrl && this._clipitUrl.includes('/api/timedtext')) {
        const langMatch = this._clipitUrl.match(/[&?]lang=([^&]+)/);
        const lang = langMatch ? langMatch[1] : 'unknown';
        const videoMatch = this._clipitUrl.match(/[&?]v=([^&]+)/);
        const videoId = videoMatch ? videoMatch[1] : 'unknown';
        const uniqueKey = `${videoId}_${lang}`;

        // Skip if we already captured this
        if (capturedUrls.has(uniqueKey)) {
          console.log('[ClipIt Interceptor] Already captured via XHR:', uniqueKey);
          return;
        }

        try {
          const text = this.responseText;
          console.log('[ClipIt Interceptor] XHR timedtext response for', lang, '- length:', text.length);

          if (text && text.length > 10) {
            capturedUrls.add(uniqueKey);
            console.log('[ClipIt Interceptor] Captured timedtext via XHR:', lang, 'length:', text.length);
            window.postMessage({
              type: 'CLIPIT_TIMEDTEXT_CAPTURED',
              lang: lang,
              content: text,
              url: this._clipitUrl
            }, '*');
          } else {
            console.log('[ClipIt Interceptor] Empty or very short XHR response for', lang);
          }
        } catch (e) {
          console.log('[ClipIt Interceptor] Error processing XHR:', e.message);
        }
      }
    });
    return originalXHRSend.apply(this, args);
  };

  // YouTube often loads auto-generated captions before a document-idle content
  // script can install the interceptor above. The content script requests this
  // fallback after identifying a video; it runs in page context so it can read
  // YouTube's signed caption URLs and use the viewer's session cookies.
  async function fetchRequestedCaptionTracks(videoId, targetLanguage) {
    // The content script normally asks roughly one second after navigation,
    // but auto-generated tracks often arrive after the player shell. Keep
    // checking in page context, where YouTube's signed URLs are available.
    const deadline = Date.now() + 15000;
    let targetTrack = null;
    let englishTrack = null;
    while (Date.now() < deadline) {
      const captionTracks = getPlayerResponse()
        ?.captions?.playerCaptionsTracklistRenderer?.captionTracks || [];
      targetTrack = captionTracks.find((track) =>
        track.languageCode === targetLanguage || track.languageCode?.startsWith(`${targetLanguage}-`),
      );
      englishTrack = captionTracks.find((track) =>
        track.languageCode === 'en' || track.languageCode?.startsWith('en-'),
      );
      if (targetTrack) break;
      await new Promise((resolve) => setTimeout(resolve, 500));
    }

    if (!targetTrack) {
      console.log('[ClipIt Interceptor] No signed target caption track after waiting for', targetLanguage);
      return;
    }

    void Promise.all([
      fetchSignedTrack(targetTrack, videoId, originalFetch),
      englishTrack && englishTrack.languageCode !== targetTrack.languageCode
        ? fetchSignedTrack(englishTrack, videoId, originalFetch)
        : Promise.resolve(false),
    ]);
  }

  window.addEventListener('message', (event) => {
    if (event.source !== window || event.data?.type !== 'CLIPIT_FETCH_PAGE_CAPTIONS') return;

    const { videoId, targetLanguage } = event.data;
    void fetchRequestedCaptionTracks(videoId, targetLanguage);
  });

  console.log('[ClipIt Interceptor] YouTube timedtext interceptor installed (fetch + XHR)');
})();
